<header id="header">
    <div class="container main-menu">
        <div class="row align-items-center d-flex">
            <div id="logo">
                <a href="index"><img src="img/logo.png" alt="" title="" /></a>
            </div>
            <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <li><a class="active" href="./">Home</a></li>
                    <li><a href="about">About</a></li>
                    <!-- <li><a href="ministry">Ministry</a></li> -->
                    <li><a href="portfolio">Portfolio</a></li>
                    <!-- <li><a href="discounts">Discount Sale</a></li> -->
                    <li class="menu-has-children"><a href="#">Pages</a>
                        <ul>
                            <li><a href="contact">Contact</a></li>
                            <li><a href="services">Services</a></li>
                            <!-- <li><a href="referral">Referral</a></li> -->
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>
