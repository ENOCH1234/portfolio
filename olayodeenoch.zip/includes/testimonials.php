<section class="testimonials_area section-gap">
    <div class="container">
        <div class="testi_slider owl-carousel">
            <div class="item">
                <div class="testi_item">
                    <img src="img/princ.png" alt="">
                    <h4>Deacon O.A. Makinde</h4>
                    <ul class="list">
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                    </ul>
                    <div class="wow fadeIn" data-wow-duration="1s">
                        <p>
                            Our school website and portal is up and running at an affordable price.
                        </p>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="testi_item">
                    <img src="img/nbc-logo.png" alt="">
                    <h4>The Nigerian Baptist Convention</h4>
                    <ul class="list">
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                    </ul>
                    <div class="wow fadeIn" data-wow-duration="1s">
                        <p>
                            Apps are developed according to taste.
                        </p>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="testi_item">
                    <img src="img/ola.png" alt="">
                    <h4>Mrs. Helen Olawore</h4>
                    <ul class="list">
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                        <li><a href="#"><i class="fa fa-star"></i></a></li>
                    </ul>
                    <div class="wow fadeIn" data-wow-duration="1s">
                        <p>
                            Enoch is a good digital person and trainer.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
